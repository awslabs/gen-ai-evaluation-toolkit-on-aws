from logging import getLogger
from typing import Optional

from experiment_lambda.api.utils.api_gw_lambda_handler import (
    create_api_gw_lambda_handler,
)
from experiment_lambda.api.utils.api_models import (
    ListExperimentsRequest,
    ListExperimentsResponse,
)
from experiment_lambda.api.utils.mapper import (
    map_experiment,
    map_view_type,
)
from experiment_lambda.utils.mlflow_client import get_mlflow_client

logger = getLogger(__name__)


def list_experiments(request: ListExperimentsRequest) -> ListExperimentsResponse:
    """
    Lambda handler to list MLflow experiments.

    Args:
        request: Validated ListExperimentsRequest
        context: Lambda context

    Returns:
        ListExperimentsResponse with list of experiments
    """
    filter_expr = request.filter
    order_by = request.orderBy
    view_type = request.viewType
    max_results = request.maxResults
    next_token = request.nextToken

    logger.info(
        "Listing experiments with the following parameters: "
        f"filter={filter_expr}, "
        f"view_type={view_type}, "
        f"max_results={max_results}, "
        f"next_token={next_token}"
    )

    client = get_mlflow_client()

    mlflow_view_type = map_view_type(view_type)

    search_result = client.search_experiments(
        filter_string=filter_expr,
        order_by=order_by,
        view_type=mlflow_view_type,
        page_token=next_token,
        max_results=max_results,
    )

    next_token_value: Optional[str] = search_result.token

    experiments = [map_experiment(dto) for dto in search_result]

    logger.info(f"Successfully retrieved {len(experiments)} experiments")

    return ListExperimentsResponse(experiments=experiments, nextToken=next_token_value)


handler = create_api_gw_lambda_handler(
    input_model=ListExperimentsRequest,
    output_model=ListExperimentsResponse,
    operation=list_experiments,
)
