## Setup

You need to install the version of Python declared in `mise.toml`. We recommend that you install [mise](https://mise.jdx.dev/); if you
do then it will automatically install the version declared in that file (including when it changes) and make it active when you're in this
directory.

## Commands

### Build Commands

```bash
# Standard build (creates Lambda.zip and other artifacts)
brazil-build

# Only create the Lambda zip package
brazil-build run make-archive

# Generate Software Bill of Materials (SBOM)
brazil-build run sbom:generate

# Generate attribution notices
brazil-build run generate-notices

# Copy BATS publisher configuration
brazil-build run copy-bats-publisher-configuration
```

### Development Commands

```bash
# Run tests
brazil-build test

# Run type checking
brazil-build run typing

# Lint code
brazil-build run lint

# Run all verification checks without modifying code
brazil-build run check

# Format code (modifies files to follow style rules)
brazil-build run format

# Fix code style and lint issues automatically (modifies files)
brazil-build run fix
```
