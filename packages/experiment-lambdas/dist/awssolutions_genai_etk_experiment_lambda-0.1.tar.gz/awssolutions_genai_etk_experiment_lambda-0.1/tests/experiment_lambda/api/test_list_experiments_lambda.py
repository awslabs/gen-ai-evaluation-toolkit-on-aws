import unittest
from typing import Any, Generic, TypeVar
from unittest.mock import MagicMock, patch

from experiment_lambda.api.list_experiments_lambda import list_experiments
from experiment_lambda.api.utils.api_models import (
    Experiment,
    ListExperimentsRequest,
    ListExperimentsResponse,
    ViewType,
)

T = TypeVar("T")


class TestListExperimentsLambda(unittest.TestCase):
    """Tests for list_experiments_lambda.py"""

    @patch("experiment_lambda.api.list_experiments_lambda.map_experiment")
    @patch("experiment_lambda.api.list_experiments_lambda.map_view_type")
    @patch("experiment_lambda.api.list_experiments_lambda.get_mlflow_client")
    def test_list_experiments_success(
        self,
        mock_get_mlflow_client: MagicMock,
        mock_map_view_type: MagicMock,
        mock_map_experiment: MagicMock,
    ) -> None:
        """Test successful listing of experiments"""
        # Arrange
        mock_client = MagicMock()
        mock_get_mlflow_client.return_value = mock_client

        mlflow_view_type = 1  # ACTIVE_ONLY
        mock_map_view_type.return_value = mlflow_view_type

        # Create mock experiments
        mock_mlflow_experiment1 = MagicMock()
        mock_mlflow_experiment2 = MagicMock()

        # Create a MlflowPagedList with mocked experiments
        class MockPagedList(list[Any], Generic[T]):
            token = "next-token-value"

        mock_search_result = MockPagedList[Any]([mock_mlflow_experiment1, mock_mlflow_experiment2])
        mock_client.search_experiments.return_value = mock_search_result

        # Mock mapped experiments
        mapped_experiment1 = Experiment(
            id="exp-1", name="Experiment 1", description="Test Description 1"
        )
        mapped_experiment2 = Experiment(
            id="exp-2", name="Experiment 2", description="Test Description 2"
        )
        mock_map_experiment.side_effect = [mapped_experiment1, mapped_experiment2]

        # Create request
        request = ListExperimentsRequest(
            filter="name LIKE '%test%'",
            orderBy=["name ASC"],
            viewType=ViewType.ACTIVE_ONLY,
            maxResults=100,
            nextToken="token-123",
        )

        # Act
        result = list_experiments(request)

        # Assert
        mock_map_view_type.assert_called_once_with(ViewType.ACTIVE_ONLY)
        mock_client.search_experiments.assert_called_once_with(
            filter_string="name LIKE '%test%'",
            order_by=["name ASC"],
            view_type=mlflow_view_type,
            page_token="token-123",
            max_results=100,
        )

        self.assertIsInstance(result, ListExperimentsResponse)
        self.assertEqual(len(result.experiments), 2)
        self.assertEqual(result.experiments[0], mapped_experiment1)
        self.assertEqual(result.experiments[1], mapped_experiment2)
        self.assertEqual(result.nextToken, "next-token-value")

    @patch("experiment_lambda.api.list_experiments_lambda.map_view_type")
    @patch("experiment_lambda.api.list_experiments_lambda.get_mlflow_client")
    def test_list_experiments_empty_result(
        self,
        mock_get_mlflow_client: MagicMock,
        mock_map_view_type: MagicMock,
    ) -> None:
        """Test listing experiments with empty result"""
        # Arrange
        mock_client = MagicMock()
        mock_get_mlflow_client.return_value = mock_client

        mlflow_view_type = 1  # ACTIVE_ONLY
        mock_map_view_type.return_value = mlflow_view_type

        # Create empty MlflowPagedList
        class MockPagedList(list[Any], Generic[T]):
            token = None

        mock_search_result = MockPagedList[Any]([])
        mock_client.search_experiments.return_value = mock_search_result

        # Create request with defaults
        request = ListExperimentsRequest()

        # Act
        result = list_experiments(request)

        # Assert
        mock_map_view_type.assert_called_once_with(ViewType.ACTIVE_ONLY)
        mock_client.search_experiments.assert_called_once_with(
            filter_string=None,
            order_by=None,
            view_type=mlflow_view_type,
            page_token=None,
            max_results=1000,
        )

        self.assertIsInstance(result, ListExperimentsResponse)
        self.assertEqual(len(result.experiments), 0)
        self.assertIsNone(result.nextToken)


if __name__ == "__main__":
    unittest.main()
